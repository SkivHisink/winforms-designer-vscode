namespace VisualStudioReference.Modern;

partial class S024ClipboardCollisionForm
{
    private System.Windows.Forms.Button submitButton = null!;

    private void InitializeComponent()
    {
        submitButton = new System.Windows.Forms.Button();
        button1 = new System.Windows.Forms.Button();
        SuspendLayout();
        // 
        // submitButton
        // 
        submitButton.Location = new System.Drawing.Point(40, 40);
        submitButton.Name = "submitButton";
        submitButton.Size = new System.Drawing.Size(124, 32);
        submitButton.TabIndex = 0;
        submitButton.Text = "Submit existing";
        submitButton.UseVisualStyleBackColor = true;
        // 
        // button1
        // 
        button1.Location = new System.Drawing.Point(98, 74);
        button1.Name = "button1";
        button1.Size = new System.Drawing.Size(124, 32);
        button1.TabIndex = 1;
        button1.Text = "Submit existing";
        button1.UseVisualStyleBackColor = true;
        // 
        // S024ClipboardCollisionForm
        // 
        AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
        AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
        ClientSize = new System.Drawing.Size(320, 180);
        Controls.Add(button1);
        Controls.Add(submitButton);
        Name = "S024ClipboardCollisionForm";
        Text = "S024 clipboard name collision";
        ResumeLayout(false);
    }

    private System.Windows.Forms.Button button1;
}
