namespace VisualStudioReference.Modern;

partial class S085InheritedDerivedForm
{
    private void InitializeComponent()
    {
        SuspendLayout();
        // 
        // S085InheritedDerivedForm
        // 
        AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
        AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
        ClientSize = new System.Drawing.Size(340, 180);
        Name = "S085InheritedDerivedForm";
        Text = "S085 inherited derived";
        ResumeLayout(false);
    }
}
