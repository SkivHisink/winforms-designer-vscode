namespace DemoApp;
partial class GroupMoveForm
{
    private System.Windows.Forms.Button button1;
    private System.Windows.Forms.Button button2;
    private void InitializeComponent()
    {
        button1 = new System.Windows.Forms.Button();
        button2 = new System.Windows.Forms.Button();
        SuspendLayout();
        // 
        // button1
        // 
        button1.Location = new System.Drawing.Point(38, 36);
        button1.Name = "button1";
        button1.Size = new System.Drawing.Size(75, 23);
        button1.TabIndex = 1;
        // 
        // button2
        // 
        button2.Location = new System.Drawing.Point(67, 69);
        button2.Name = "button2";
        button2.Size = new System.Drawing.Size(75, 23);
        button2.TabIndex = 0;
        // 
        // GroupMoveForm
        // 
        ClientSize = new System.Drawing.Size(284, 261);
        Controls.Add(button2);
        Controls.Add(button1);
        Name = "GroupMoveForm";
        ResumeLayout(false);
    }
}
