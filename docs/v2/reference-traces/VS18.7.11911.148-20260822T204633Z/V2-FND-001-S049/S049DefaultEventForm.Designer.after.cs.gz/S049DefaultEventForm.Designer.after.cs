namespace VisualStudioReference.Modern;

partial class S049DefaultEventForm
{
    private System.Windows.Forms.Button button1 = null!;

    private void InitializeComponent()
    {
        button1 = new System.Windows.Forms.Button();
        SuspendLayout();
        // 
        // button1
        // 
        button1.Location = new System.Drawing.Point(36, 42);
        button1.Name = "button1";
        button1.Size = new System.Drawing.Size(152, 38);
        button1.TabIndex = 0;
        button1.Text = "Create Click handler";
        button1.UseVisualStyleBackColor = true;
        button1.Click += button1_Click;
        // 
        // S049DefaultEventForm
        // 
        AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
        AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
        ClientSize = new System.Drawing.Size(300, 150);
        Controls.Add(button1);
        Name = "S049DefaultEventForm";
        Text = "S049 default event";
        ResumeLayout(false);
    }
}
