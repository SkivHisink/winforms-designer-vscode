namespace VisualStudioReference.Modern;

partial class S045ColorEditorForm
{
    private System.Windows.Forms.Button button1 = null!;

    private void InitializeComponent()
    {
        button1 = new System.Windows.Forms.Button();
        SuspendLayout();
        // 
        // button1
        // 
        button1.BackColor = System.Drawing.Color.Red;
        button1.Location = new System.Drawing.Point(48, 54);
        button1.Name = "button1";
        button1.Size = new System.Drawing.Size(160, 42);
        button1.TabIndex = 0;
        button1.Text = "Choose Blue";
        button1.UseVisualStyleBackColor = false;
        // 
        // S045ColorEditorForm
        // 
        AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
        AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
        ClientSize = new System.Drawing.Size(360, 180);
        Controls.Add(button1);
        Name = "S045ColorEditorForm";
        Text = "S045 Color editor apply";
        ResumeLayout(false);
    }
}
