namespace VisualStudioReference.Modern;

partial class S042PaddingForm
{
    private System.Windows.Forms.Button button1 = null!;

    private void InitializeComponent()
    {
        button1 = new System.Windows.Forms.Button();
        SuspendLayout();
        // 
        // button1
        // 
        button1.Location = new System.Drawing.Point(36, 42);
        button1.Name = "button1";
        button1.Padding = new System.Windows.Forms.Padding(8, 4, 5, 6);
        button1.Size = new System.Drawing.Size(160, 40);
        button1.TabIndex = 0;
        button1.Text = "Padding 3,4,5,6";
        button1.UseVisualStyleBackColor = true;
        // 
        // S042PaddingForm
        // 
        AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
        AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
        ClientSize = new System.Drawing.Size(320, 160);
        Controls.Add(button1);
        Name = "S042PaddingForm";
        Text = "S042 Padding subproperty";
        ResumeLayout(false);
    }
}
