namespace VisualStudioReference.Net48
{
    partial class S087InheritedDerivedForm
    {
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(0, 0);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 0;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // S087InheritedDerivedForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(360, 220);
            this.Controls.Add(this.button1);
            this.Name = "S087InheritedDerivedForm";
            this.Text = "S087 inherited derived";
            this.Controls.SetChildIndex(this.button1, 0);
            this.Controls.SetChildIndex(this.basePanel, 0);
            this.ResumeLayout(false);

        }

        private System.Windows.Forms.Button button1;
    }
}
