namespace VisualStudioReference.Modern;

partial class S061OutlineRenameForm
{
    private System.Windows.Forms.Button button1 = null!;
    private System.Windows.Forms.TextBox textBox1 = null!;

    private void InitializeComponent()
    {
        button1 = new System.Windows.Forms.Button();
        textBox1 = new System.Windows.Forms.TextBox();
        SuspendLayout();
        // 
        // button1
        // 
        button1.Location = new System.Drawing.Point(20, 20);
        button1.Name = "button1";
        button1.Size = new System.Drawing.Size(110, 30);
        button1.TabIndex = 0;
        button1.Text = "button1";
        button1.UseVisualStyleBackColor = true;
        // 
        // textBox1
        // 
        textBox1.Location = new System.Drawing.Point(20, 70);
        textBox1.Name = "textBox1";
        textBox1.Size = new System.Drawing.Size(160, 23);
        textBox1.TabIndex = 1;
        // 
        // S061OutlineRenameForm
        // 
        AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
        AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
        ClientSize = new System.Drawing.Size(320, 150);
        Controls.Add(textBox1);
        Controls.Add(button1);
        Name = "S061OutlineRenameForm";
        Text = "S061 outline rename";
        ResumeLayout(false);
        PerformLayout();
    }
}
